package Reto4;

import java.util.Calendar;
import java.util.GregorianCalendar;

public class Panel {

    private int identificador, anioFabrica, precioVenta;
    private String identificadorSerie, tipoPanel, nombreModelo, descripcion;

    public Panel() {
    }

    public Panel(int identificador, int anioFabrica, int precioVenta, String identificadorSerie, String tipoPanel, String nombreModelo, String descripcion) {
        this.identificador = identificador;
        this.anioFabrica = anioFabrica;
        this.precioVenta = precioVenta;
        this.identificadorSerie = identificadorSerie;
        this.tipoPanel = tipoPanel;
        this.nombreModelo = nombreModelo;
        this.descripcion = descripcion;
    }

    public int getIdentificador() {
        return identificador;
    }

    public int getAnioFabrica() {
        return anioFabrica;
    }

    public int getPrecioVenta() {
        return precioVenta;
    }

    public String getIdentificadorSerie() {
        return identificadorSerie;
    }

    public String getTipoPanel() {
        return tipoPanel;
    }

    public String getNombreModelo() {
        return nombreModelo;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public String estadoPanel(int anioFabricacion) {
        Calendar anioActual = new GregorianCalendar();
        int fecha = anioActual.get(Calendar.YEAR);
        fecha -= anioFabricacion;
        String estado = "";
        if (fecha >= 0 && fecha < 2) {
            estado = "nuevo";
        } else if (fecha >= 2 && fecha < 5) {
            estado = "medianamente usado";
        } else if (fecha >= 5) {
            estado = "usado";
        }
        return estado;
    }
}
