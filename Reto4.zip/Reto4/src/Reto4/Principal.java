package Reto4;

import java.io.*;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import javax.swing.JOptionPane;
import java.util.Date;
import java.util.GregorianCalendar;

public class Principal {

    private static int identificador, choice, anioFabrica, precioVenta;
    static long numId;
    private static String idSerie, descripcion, tipoPanel, modelo, fechaEntrada, horaEntrada, tipoId, nombre, nombreEmpresa, fechaFinal;
    private static String[] opciones1 = {"Sí", "No"};
    private static String[] opciones2 = {"Monocristalino", "Policristalino", "Película delgada", " CVP"};
    private static String[] opciones3 = {"CC", "CE"};
    private static DateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
    private static DateFormat formatoHora = new SimpleDateFormat("hh:mm");
    private static DecimalFormat puntoMil = new DecimalFormat("###,###.##");
    private static Calendar calendario = new GregorianCalendar();
    static Date fecha1, fecha2, hora;

    public static void main(String[] args) throws IngresoException, ParseException {
        JOptionPane.showMessageDialog(null, "Recuerda ingresar los datos correctamente", "SISTEMA DE VENTA DE PANELES", JOptionPane.INFORMATION_MESSAGE);
        identificador = Integer.parseInt(JOptionPane.showInputDialog(null, "Ingresa el identificador único del panel (solo números - no mayor a 9 dígitos)", "SISTEMA DE VENTAS DE PANELES", JOptionPane.INFORMATION_MESSAGE));
        choice = JOptionPane.showOptionDialog(null, "¿El panel tiene identificador de serie?", "RESPONDE", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null, opciones1, 0);
        if (choice == 0) {
            idSerie = JOptionPane.showInputDialog(null, "Ingresa el identificador de serie del panel (números y letras)", "INFORMACIÓN DEL PANEL", JOptionPane.INFORMATION_MESSAGE);
        } else {
            idSerie = "N/A";
        }
        descripcion = JOptionPane.showInputDialog(null, "Ingresa una breve descripción del panel", "INFORMACIÓN DEL PANEL", JOptionPane.INFORMATION_MESSAGE);
        choice = JOptionPane.showOptionDialog(null, "¿Qué tipo de panel es?", "INFORMACIÓN DEL PANEL", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null, opciones2, 0);
        tipoPanel(choice);
        modelo = JOptionPane.showInputDialog(null, "Ingresa el modelo del panel", "INFORMACIÓN DEL PANEL", JOptionPane.INFORMATION_MESSAGE);
        anioFabrica = Integer.parseInt(JOptionPane.showInputDialog(null, "Ingresa el año de fabricación (mayor a 1960 y menor al año actual)", "INFORMACIÓN DEL PANEL", JOptionPane.INFORMATION_MESSAGE));
        excepciones();
        precioVenta = Integer.parseInt(JOptionPane.showInputDialog(null, "Ingresa el precio de venta en COP (no negativos)", "INFORMACIÓN DEL PANEL", JOptionPane.INFORMATION_MESSAGE));
        excepciones();
        Panel panel = new Panel(identificador, anioFabrica, precioVenta, idSerie, tipoPanel, modelo, descripcion);
        JOptionPane.showMessageDialog(null, "Identificador único:  " + identificador + "\nIdentificador de serie:  " + idSerie + "\nDescripción del panel:  " + descripcion + "\nTipo de panel:  " + tipoPanel + "\nModelo:  " + modelo + "\nAño de fabricación:  " + anioFabrica + "\nPrecio de venta:  " + puntoMil.format(precioVenta), "RESUMEN - PANEL", JOptionPane.PLAIN_MESSAGE);
        //----------------------------------- Final de la información del panel ------------------------------------
        fechaEntrada = JOptionPane.showInputDialog(null, "Ingresa la fecha de venta en formato DD/MM/YYYY\n(año no puede ser menor al " + anioFabrica + ")", "INFORMACIÓN DE VENTA", JOptionPane.INFORMATION_MESSAGE);
        fecha1 = formato.parse(fechaEntrada);
        calendario.setTime(fecha1);
        fechaEntrada = formato.format(calendario.getTime());
        excepcionesFechas();
        horaEntrada = JOptionPane.showInputDialog(null, "Ingresa la hora de venta en formato hh:mm (hora militar/24 horas)", "INFORMACIÓN DE VENTA", JOptionPane.INFORMATION_MESSAGE);
        hora = formatoHora.parse(horaEntrada);
        calendario.setTime(hora);
        horaEntrada = formatoHora.format(calendario.getTime());
        choice = JOptionPane.showOptionDialog(null, "¿Qué tipo de identificación tiene el comprador", "INFORMACIÓN DE VENTA", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null, opciones3, 0);
        tipoId(choice);
        numId = Long.parseLong(JOptionPane.showInputDialog(null, "Ingresa el número de identificación (solo números)", "INFORMACIÓN DE VENTA", JOptionPane.INFORMATION_MESSAGE));
        nombre = JOptionPane.showInputDialog(null, "Ingresa el nombre completo del comprador", "INFORMACIÓN DE VENTA", JOptionPane.INFORMATION_MESSAGE);
        descripcion = JOptionPane.showInputDialog(null, "Ingresa una breve descripción del uso que se le dará al panel", "INFORMACIÓN DE VENTA", JOptionPane.INFORMATION_MESSAGE);
        Venta venta = new Venta(panel.getIdentificador(), panel.getPrecioVenta(), fechaEntrada, horaEntrada, tipoId, numId, nombre, descripcion);
        JOptionPane.showMessageDialog(null, "Identificador del panel:  " + venta.getIdentificadorPanel() + "\nFecha de venta:  " + fechaEntrada + "\nHora de venta:  " + horaEntrada + "\nTipo de ID del comprador:  " + tipoId + "\nID del comprador:  " + numId + "\nNombre completo del comprador:  " + nombre + "\nUso del panel:  " + descripcion, "RESUMEN - VENTA", JOptionPane.PLAIN_MESSAGE);
        //------------------------------------ Final de la información de venta -----------------------------------   
        nombreEmpresa = JOptionPane.showInputDialog(null, "Ingresa el nombre de la empresa del seguro", "INFORMACIÓN DEL SEGURO", JOptionPane.INFORMATION_MESSAGE);
        fechaFinal = JOptionPane.showInputDialog(null, "Ingresa la fecha de finalización del seguro en formato DD/MM/YYYY\n(Debe ser mayor a " + fechaEntrada + ")", "INFORMACIÓN DEL SEGURO", JOptionPane.INFORMATION_MESSAGE);
        fecha2 = formato.parse(fechaFinal);
        calendario.setTime(fecha2);
        fechaFinal = formato.format(calendario.getTime());
        excepcionesFechas();
        descripcion = JOptionPane.showInputDialog(null, "Ingresa una descripción del seguro", "INFORMACIÓN DEL SEGURO", JOptionPane.INFORMATION_MESSAGE);
        Seguro seguro = new Seguro(nombreEmpresa, descripcion, venta.getFecha(), fechaFinal, panel.getIdentificador());
        JOptionPane.showMessageDialog(null, "Empresa de seguro:  " + nombreEmpresa + "\nFecha inicio de cobertura:  " + fechaEntrada + "\nFecha finalización de cobertura:  " + fechaFinal + "\nDescripción de seguro:  " + descripcion + "\nIdentificador de panel:  " + panel.getIdentificador(), "RESUMEN - SEGURO", JOptionPane.PLAIN_MESSAGE);
        JOptionPane.showMessageDialog(null, "Días de cobertura del seguro:  " + seguro.contadorDias() + "\nDías a partir de la compra:  " + venta.numPostVenta() + "\nEsstado del panel vendido:  " + panel.estadoPanel(anioFabrica), "INFORMACIÓN ADICIONAL", JOptionPane.INFORMATION_MESSAGE);
    }

    private static void excepciones() throws IngresoException {
        Calendar anioActual = new GregorianCalendar();
        int anio = anioActual.get(Calendar.YEAR);
        if (anioFabrica <= 1960 || anioFabrica >= anio) {
            throw new IngresoException();
        }
        if (precioVenta < 0) {
            throw new IngresoException();
        }
    }

    private static void excepcionesFechas() throws ParseException, IngresoException {
        fecha1 = formato.parse(fechaEntrada);
        calendario.setTime(fecha1);
        int datoAnio = calendario.get(Calendar.YEAR);
        if (fechaEntrada != null && fechaFinal != null) {
            fecha2 = formato.parse(fechaFinal);
            if (fecha1.after(fecha2)) {
                throw new IngresoException();
            }
        }
        if (datoAnio < anioFabrica) {
            throw new IngresoException();
        }
    }

    private static void tipoId(int eleccion) {
        switch (eleccion) {
            case 0:
                tipoId = "cédula de ciudadanía";
                break;
            case 1:
                tipoId = "cédula extranjera";
                break;

        }
    }

    private static void tipoPanel(int eleccion) {
        switch (eleccion) {
            case 0:
                tipoPanel = "monocristalino";
                break;
            case 1:
                tipoPanel = "policristalino";
                break;
            case 2:
                tipoPanel = "película delgada";
                break;
            case 3:
                tipoPanel = "CVP";
                break;

        }
    }

}
