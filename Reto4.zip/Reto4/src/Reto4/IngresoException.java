package Reto4;

public class IngresoException extends Exception {

    public IngresoException() {
        super("el dato ingresado es erróneo");
    }

}
