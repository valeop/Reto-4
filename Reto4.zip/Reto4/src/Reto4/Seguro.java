package Reto4;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Seguro {

    private String nombreSeguro, descripcion, fechaInicio, fechaFinal;
    private int identificador;
    private static DateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
    private Date fecha1, fecha2;

    public Seguro() {
    }

    public Seguro(String nombreSeguro, String descripcion, String fechaInicio, String fechaFinal, int identificador) {
        this.nombreSeguro = nombreSeguro;
        this.descripcion = descripcion;
        this.fechaInicio = fechaInicio;
        this.fechaFinal = fechaFinal;
        this.identificador = identificador;
    }

    public String getNombreSeguro() {
        return nombreSeguro;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public String getFechaInicio() {
        return fechaInicio;
    }

    public String getFechaFinal() {
        return fechaFinal;
    }

    public int getIdentificador() {
        return identificador;
    }

    public int contadorDias() throws ParseException {
        long inicio, finall;
        fecha1 = formato.parse(fechaInicio);
        fecha2 = formato.parse(fechaFinal);
        inicio = fecha1.getTime();
        finall = fecha2.getTime();
        long desde = (long) Math.floor(inicio / (1000 * 60 * 60 * 24));
        long hasta = (long) Math.floor(finall / (1000 * 60 * 60 * 24));
        long dias = hasta - desde;
        return (int) dias;
    }
}
