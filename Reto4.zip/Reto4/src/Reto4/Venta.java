package Reto4;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

public class Venta {

    private int identificadorPanel, valorPago;
    private long numId;
    private String fecha, hora, tipoId, fullName, descripcion;
    private static DateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
    private Date fecha1, fecha2;

    public Venta(int identificadorPanel, int valorPago, String fecha, String hora, String tipoId, long numId, String fullName, String descripcion) {
        this.identificadorPanel = identificadorPanel;
        this.valorPago = valorPago;
        this.fecha = fecha;
        this.hora = hora;
        this.tipoId = tipoId;
        this.numId = numId;
        this.fullName = fullName;
        this.descripcion = descripcion;
    }

    public int getIdentificadorPanel() {
        return identificadorPanel;
    }

    public int getValorPago() {
        return valorPago;
    }

    public long getNumId() {
        return numId;
    }

    public String getFecha() {
        return fecha;
    }

    public String getHora() {
        return hora;
    }

    public String getTipoId() {
        return tipoId;
    }

    public String getFullName() {
        return fullName;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public int numPostVenta() throws ParseException {
        Calendar fechaActual = new GregorianCalendar();
        long inicio, finall;
        fecha1 = formato.parse(fecha);
        fecha2 = new Date();
        inicio = fecha1.getTime();
        finall = fecha2.getTime();
        long desde = (long) Math.floor(inicio / (1000 * 60 * 60 * 24));
        long hasta = (long) Math.floor(finall / (1000 * 60 * 60 * 24));
        long dias = hasta - desde;
        return (int) dias;
    }
}
